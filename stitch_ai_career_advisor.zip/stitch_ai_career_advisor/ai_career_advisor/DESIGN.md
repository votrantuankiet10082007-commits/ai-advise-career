---
name: AI Career Advisor
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#464555'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#5b598c'
  on-secondary: '#ffffff'
  secondary-container: '#c7c3fe'
  on-secondary-container: '#514f81'
  tertiary: '#00524b'
  on-tertiary: '#ffffff'
  tertiary-container: '#006c63'
  on-tertiary-container: '#81eddf'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#e3dfff'
  secondary-fixed-dim: '#c4c1fb'
  on-secondary-fixed: '#181445'
  on-secondary-fixed-variant: '#444173'
  tertiary-fixed: '#89f5e7'
  tertiary-fixed-dim: '#6bd8cb'
  on-tertiary-fixed: '#00201d'
  on-tertiary-fixed-variant: '#005049'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.005em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  data-mono:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system embodies an authoritative, inspiring, and sharp edtech aesthetic tailored for Vietnamese technology students and early-career software engineers. It bridges academic rigor with high-velocity tech industry standards, cultivating feelings of forward momentum, competence, and clarity.

The aesthetic blends **Modern Corporate SaaS** with **Tactile Analytical Glass**:
- Ultra-clean structural surfaces built on cool slate foundations.
- High-contrast, mathematically precise data displays (match scores, skill telemetry, career roadmaps).
- Purposeful atmospheric indigo glows and subtle linear gradients that convey intelligence and technological precision without feeling game-like or gimmicky.
- Visual cadence is calm, methodical, and empowering, reducing cognitive friction during high-stress career transitions.

## Colors

The palette establishes clear visual hierarchy, operational confidence, and real-time semantic feedback:

- **Primary (`#4F46E5` - Electric Indigo):** Drives primary actions, system-level AI prompts, and key active states.
- **Deep Navy Base (`#1E1B4B` - Midnight Indigo):** Serves as high-contrast display text, executive card headers, and navigation anchors.
- **Match & Success Accents (`#0D9488` Teal & `#10B981` Emerald):** Represents AI alignment, verified skills, passed milestones, and high career-compatibility percentiles.
- **Gap & Focus Warning (`#F59E0B` Amber / `#D97706` Deep Amber):** Signals technical skill gaps, missing course requirements, and high-priority action items.
- **Neutral Stack:**
  - Background Canvas: `#F8FAFC` (Slate 50)
  - Surface Pure: `#FFFFFF`
  - Subtle Borders & Separators: `#E2E8F0` (Slate 200)
  - Muted Borders: `#CBD5E1` (Slate 300)
  - Body Text: `#334155` (Slate 700)
  - Muted Text / Meta: `#64748B` (Slate 500)

Semantic rules:
- Interactive elements must maintain a minimum 4.5:1 contrast against `#F8FAFC` and `#FFFFFF`.
- Never use full `#000000` for text; prioritize `#1E1B4B` for headlines and `#334155` for sustained body reading.

## Typography

Typography pairs **Plus Jakarta Sans** for structural headers with **Inter** for sustained technical legibility:

- **Plus Jakarta Sans:** Provides friendly geometry, distinct rounded aperture cuts, and confident weights. Used exclusively for brand identity, page headings, KPI metric values, and section intros.
- **Inter:** Ensures maximum clarity for dense Vietnamese diacritics (dấu ngã, hỏi, nặng) across dense syllabus lists, job requirement descriptions, and telemetry charts.
- **Diacritic Protection:** Minimum line-height is set to 1.35x across all typographic levels to prevent vertical clipping of combined tone markers common in Vietnamese technical vocabularies.

## Layout & Spacing

The platform utilizes a structured 12-column fluid grid system on desktop that snaps to 4 columns on mobile, backed by an 8pt atomic spacing model (with 4pt sub-steps for micro-components):

- **Breakpoints:**
  - Mobile: `< 640px` (4-column grid, 16px margins, 16px gutters)
  - Tablet: `640px - 1024px` (8-column grid, 24px margins, 20px gutters)
  - Desktop: `> 1024px` (12-column grid, max canvas width 1280px, 32px margins, 24px gutters)
  - Wide Display: `> 1440px` (Center-locked 1280px - 1360px container)

- **Layout Flow:**
  - On mobile, multi-panel comparison tools (e.g., Target Role vs. Current Skills) stack vertically into an accordion or tabbed interface.
  - On desktop, persistent AI chat or career roadmap sidebars lock to a 380px fixed-width column, while dynamic analytical canvases span the remaining 8 columns.

## Elevation & Depth

Visual hierarchy uses **Tonal Layering with Ambient Indigo Tinting** and razor-sharp border outlines:

- **Level 0 (Base Canvas):** `#F8FAFC`. Completely flat with no shadow.
- **Level 1 (Cards & Data Sections):** `#FFFFFF` surface enclosed by a 1px solid border in `#E2E8F0`. Shadow: `0 1px 3px 0 rgba(30, 27, 75, 0.04), 0 1px 2px -1px rgba(30, 27, 75, 0.04)`.
- **Level 2 (Interactive Floating / Active Hover):** `#FFFFFF` surface with elevated depth. Shadow: `0 10px 15px -3px rgba(79, 70, 229, 0.08), 0 4px 6px -4px rgba(30, 27, 75, 0.03)`. Border shifts to `#CBD5E1`.
- **Level 3 (Modals, Overlays, Dropdowns):** `#FFFFFF` surface with `0 20px 25px -5px rgba(30, 27, 75, 0.12), 0 8px 10px -6px rgba(30, 27, 75, 0.04)`.
- **AI Recommendation Highlights:** Semi-transparent linear borders (`linear-gradient(135deg, rgba(79, 70, 229, 0.4), rgba(13, 148, 136, 0.4))`) combined with subtle inner glows (`inset 0 0 12px rgba(79, 70, 229, 0.03)`).

## Shapes

The design system maintains a **Balanced Roundedness (Level 2)** geometry:
- Standard UI surfaces, cards, and input fields use `0.5rem` (8px).
- Modals, prominent milestone panels, and hero containers use `1rem` (16px).
- Badges, status chips, avatar rings, and floating AI pills use full capsule / pill styling (`9999px`).
- Sharp analytical elements (radar charts, code preview blocks, telemetry axes) retain internal squared corners (`4px` to `6px`) to signal technical precision.

## Components

### Buttons
- **Primary Action:** Solid `#4F46E5` background, `#FFFFFF` text, `border-radius: 8px`, `padding: 10px 20px`, font weight 600. Hover: `#4338CA`. Active: `#3730A3`. Focus-visible: 2px ring in `#818CF8` with 2px offset.
- **Secondary Action:** `#FFFFFF` background, 1px border `#E2E8F0`, `#1E1B4B` text. Hover: `#F8FAFC` background, `#4F46E5` text, border `#CBD5E1`.
- **AI Accent Button:** Gradient `linear-gradient(135deg, #4F46E5, #0D9488)` with white text, used strictly for core generation triggers ("Analyze Resume", "Generate Study Path").

### Badges & Match Chips
- **High Alignment / Match:** `#ECFDF5` background, `#047857` text, 1px border `#A7F3D0`, pill radius.
- **Skill Gap / Warning:** `#FFFBEB` background, `#B45309` text, 1px border `#FDE68A`, pill radius.
- **Skill Domain / Tech Stack Tag:** `#EEF2FF` background, `#4338CA` text, 1px border `#E0E7FF`, `rounded-md` (6px radius).

### Cards & Container Modules
- White canvas on `#F8FAFC` background. 1px border `#E2E8F0`. Internal padding: 24px desktop, 16px mobile.
- Headers feature clear metadata: category on top in muted small uppercase, primary role title in `headline-sm`, and right-aligned progress badges.

### Circular Progress Indicators & Match Rings
- Dual-stroke SVG rings: Track background `#E2E8F0`, active stroke `#0D9488` or `#4F46E5` with `stroke-linecap: round`.
- Center content displays the numeric percentage in `Plus Jakarta Sans` 700 with a micro `%` label.

### Radar Chart Telemetry
- Polygon grid lines in `#E2E8F0` with dashed center radii.
- Target Profile polygon: `#CBD5E1` dashed border with no fill.
- Student Current Profile polygon: `#4F46E5` border with `rgba(79, 70, 229, 0.15)` fill.
- Gap areas highlight with subtle amber markers on affected axes.

### Input Fields & Search Bars
- Background: `#FFFFFF`. 1px border `#CBD5E1`. Focus: border `#4F46E5`, box-shadow `0 0 0 3px rgba(79, 70, 229, 0.12)`.
- Icon prefixes (search, GitHub link, tech stack selector) positioned at 12px left padding with `#64748B` color.

### Checkboxes & Milestones
- Checkbox size 18x18px, rounded 4px. Checked state: `#10B981` fill with white checkmark icon.
- Interactive learning roadmap items feature vertical connecting lines in `#E2E8F0`, turning `#10B981` when preceding criteria are fulfilled.